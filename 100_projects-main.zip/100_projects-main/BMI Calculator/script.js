const arr = [12, 55, 5628, 45656, 89];
arr.sort((a, b) => a - b);
console.log(arr); // [12, 55, 89, 5628, 45656]
