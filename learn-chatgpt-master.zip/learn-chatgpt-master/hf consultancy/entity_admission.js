// Here are the 10 most commonly used entities with attributes for an Admissions Assistance Service using Mongoose, considering that the service has more than 20 agents:

// Student

// studentID(unique identifier)
// firstName
// lastName
// email
// phoneNumber
// dateOfBirth
// highSchoolID(foreign key)
// Agent

// agentID(unique identifier)
// firstName
// lastName
// email
// phoneNumber
// availability
// performanceMetrics(foreign key)
// College / University

// collegeID(unique identifier)
// name
// location
// applicationDeadline
// applicationRequirements(foreign key)
// Application

// applicationID(unique identifier)
// studentID(foreign key)
// collegeID(foreign key)
// submissionDate
// status
// decisionDate
// High School

// highSchoolID(unique identifier)
// name
// location
// Major

// majorID(unique identifier)
// name
// description
// Application Status History

// statusHistoryID(unique identifier)
// applicationID(foreign key)
// status
// timestamp
// Task

// taskID(unique identifier)
// agentID(foreign key)
// studentID(foreign key)
// description
// dueDate
// completionStatus
// Scholarship

// scholarshipID(unique identifier)
// name
// description
// eligibilityCriteria
// collegeID(foreign key)
// Communication

// communicationID(unique identifier)
// studentID(foreign key)
// agentID(foreign key)
// collegeID(foreign key)
// type(email, phone call, text message)
// date
// content
// These entities and attributes provide a solid foundation for managing the core features and data of an Admissions Assistance Service, allowing for a seamless experience for both students and agents.




// Here's an example of an 'Subject' entity with related attributes, including university name, intake, year, and tuition fees for an Admission Assistance Service company using Mongoose:

// Subject
// subjectID(unique identifier)
// universityName(string)
// subjectName(string)
// intake(string)
// year(string)
// tuitionFees(number)
// description(string)
// requirements(array of strings)
// applicationDeadline(date)
// status(string)
// The 'Subject' entity contains the following attributes:

// subjectID(unique identifier): A unique identifier for each subject.
//     universityName(string): The name of the university offering the subject.
//         subjectName(string): The name of the subject being offered.
//             intake(string): The intake session for the subject.
//                 year(string): The academic year of the subject.
//                     tuitionFees(number): The tuition fee for the subject.
//                         description(string): A brief description of the subject.
//                             requirements(array of strings): An array of requirements for the subject, such as grades, tests, or certifications.
//                                 applicationDeadline(date): The application deadline for the subject.
//                                     status(string): The current status of the subject, such as open for application or closed.
// By including these attributes, the 'Subject' entity can be used to manage and display relevant information about various university subjects, making it easier for students and agents to find and apply for suitable programs.





